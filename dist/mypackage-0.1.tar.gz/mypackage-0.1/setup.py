from setuptools import setup

setup(
	name='mypackage',
	version='0.1',
	description='A sample Python package',
	author='Jiang Zhu',
	author_email='jzhu4@alaska.edu.com',
	packages=['mypackage']
)

